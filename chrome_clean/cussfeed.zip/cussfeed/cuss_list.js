cusses = {
    'FW': //foreign word
    [
	'f***'
    ],
    'NN': //singular noun
    [
	'f***'
    ],
    'VB': //verb, base form
    [
	'f***'
    ],
    'VBP': // verb, present tense
    [
	'f***'
    ],
    'JJ': //adjective
    [
	'f***ing'
    ],
    'VBG': //gerund
    [
	'f***ing'
    ],
    'JJR': //comparative adjective
    [
	'f***ier'
    ],
    'RBR': //comparative adverb
    [
	'f***ier'
    ],
    'JJS': //superlative adjective
    [
	'f***iest'
    ],
    'RBS': //superlative adverb
    [
	'f***iest'
    ],
    'NNS': //plural noun
    [
	'f***s'
    ],
    'NNPS': //plural proper noun
    [
	'f***s'
    ],
    'VBZ': //verb, present third-person
    [
	'f***s'
    ],
    'NNP': //singular proper noun
    [
	'f***er'
    ],
    'RB': //adverb
    [
	'f***ily'
    ],
    'VBD': //verb, past tense
    [
	'f***ed'
    ],
    'VBN': //verb, past part
    [
	'f***ed'
    ]
}
    
    
